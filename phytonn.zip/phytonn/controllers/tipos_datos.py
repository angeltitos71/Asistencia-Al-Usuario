def enteros():
    e=5
    e1=0
    return dict(e=e,e1=e1)

def flotante():
    f=2.5
    f1=-3.14
    return dict(f=f,f1=f1)

def cadena():
    texto1= "hola mundo :)"
    texto= "adios mundo :("
    return dict(texto1=texto1,texto=texto)
