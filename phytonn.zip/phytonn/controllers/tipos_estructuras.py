
def mi_lista():
    mi_lista=["hola,chau,adios"]
    return dict(mi_lista=mi_lista)


def tupla():
    tupla=1,2,3,4
    return dict(tupla=tupla)

def metodo1():
    #metodo append
    metodo=["a","b","c","d"]
    metodo.append("e")
    #metodo extend
    lista=["f","g","h"]
    otra_lista=["i","j"]
    lista.extend(otra_lista)
    #metodo insert
    lista2=[1,2,3]
    lista2.insert(1,4)
    #metodo remove
    Lista3=["Banana","Manzana","Zandia"]
    Lista3.remove("Zandia")
    #metodo pop
    lista4=[10,20,30,40]
    lista4.pop()
    #metodo clear nose  puede
    #metodo Acount
    fruits = ["apple", "banana", "cherry"]
    x=fruits.count("apple")
    #metodo sort
    numeros = [123,53,6,12,153,43,16,25,109,7,12]
    numeros.sort()
    lista5=["hamburgesa","milanesa","pancho","pancho"]
    lista5.sort()
    Lista6=[1, 2, 3, 4, 5]
    Lista6.reverse()


    


   


    return dict(metodo=metodo,lista=lista,lista2=lista2,Lista3=Lista3,lista4=lista4,fruits=fruits
    ,numeros=numeros,lista5=lista5,Lista6=Lista6)
